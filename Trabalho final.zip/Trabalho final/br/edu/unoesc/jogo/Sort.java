package br.edu.unoesc.jogo;

import java.util.Random;

public class Sort {
    private final String[] palavras = {
        "Abacaxis", "Amizades", "Aventuras", "Borboleta", "Cachorros", "Cavaleiro", "Cativante", "Ciencias",
        "Colaborar", "Compromisso", "Compreensao", "Confianca", "Construir", "Criatividade", "Crescimento",
        "Desafios", "Desbravar", "Dedicao", "Determinar", "Desempenho", "Descobrir", "Desenvolve", "Elefantes",
        "Empoderar", "Empresas", "Encantada", "Energia", "Esperanca", "Exploracao", "Facilidade", "Felicidade",
        "Floresta", "Fortaleza", "Gigantesco", "Habilidade", "Humanidade", "Impactante", "Infinito", "Inspiracao",
        "Integridade", "Inovacao", "Inventar", "Lideranca", "Liberdade", "Magistral", "Maravilha", "Melodiosa",
        "Montanha", "Motivacao", "Natureza", "Parafuso", "Perseverar", "Persistir", "Pioneiros", "Planetas",
        "Potencial", "Progresso", "Realizar", "Revolucao", "Sabedoria", "Sabotagem", "Solidario", "Solidariza",
        "Superacao", "Tecnologia", "Trajetoria", "Transformar", "Transporte", "Triunfar", "Uniqueness", "Valentia",
        "Vencedores", "Virtuosos", "Vislumbrar", "Voluntario", "Absoluto", "Aconchego", "Ajudantes", "Alegria",
        "Alianca", "Amorosos", "Aprimorar", "Aprender", "Aproveitar", "Argumento", "Armazenar", "Aspiracao",
        "Assalariado", "Aumentar", "Auxiliar", "Batalhador", "Bem‑estar", "Benevolo", "Beneficio", "Caloroso",
        "Carinhoso", "Cativante", "Celebracao", "Certeza", "Claridade", "Cooperacao", "Coordenar", "Coragem",
        "Crianca", "Criativo", "Curiosidade", "Decisao", "Dedicar", "Delicioso", "Despertar", "Diligente",
        "Dinamico", "Direcao", "Educacao", "Eficacia", "Eficiente", "Elogiar", "Empatia", "Energetico",
        "Envolvente", "Evoluir", "Exemplo", "Excelencia", "Exclusivo", "Experiencia", "Fascinar", "Favoravel",
        "Fidelidade", "Forteza", "Generoso", "Gratidao", "Gratificante", "Harmonia", "Heroico", "Honestidade",
        "Iluminar", "Imaginacao", "Imparcial", "Importante", "Incrivel", "Influente", "Integrar", "Jovialidade",
        "Justica", "Libertar", "Liderar", "Luminoso", "Motivador", "Nobreza", "Objetivo", "Otimismo", "Paciente",
        "Paciencia", "Perfeito", "Perseverar", "Persistente", "Positivo", "Precioso", "Proteger", "Radiante",
        "Realizacao", "Reconhecer", "Refletir", "Resiliente", "Respeitar", "Responsavel", "Riqueza", "Satisfacao",
        "Seguranca", "Simpatico", "Sinceridade", "Solidariedade", "Solucao", "Sonhador", "Tenacidade",
        "Transformador", "Triunfante", "Unidade", "Valentia", "Vitorioso", "Vibrante", "Vivencia", "Acrobatas",
        "Adaptavel", "Admiravel", "Agradecer", "Agricola", "Altruismo", "Amizade", "Analisar", "Aneladas",
        "Aplaudir", "Apreciar", "Armadura", "Armoniosa", "Arrebolar", "Articulado", "Ascendente", "Assentada",
        "Atencioso", "Autentico", "Aventureiro", "Azedume", "Beneficiar", "Bondade", "Bravura", "Brilhante",
        "Caminhada", "Cativante", "Celebração", "Certeza", "Companheiro", "Conectar", "Conquistar", "Constante",
        "Coragem", "Criadora", "Criativo", "Dedicacao", "Desenlace", "Destemido", "Determinado", "Devocional",
        "Dinamico", "Discipulo", "Distinto", "Dominante", "Doacao", "Duradouro", "Eficiente"
    };

    private final Random random = new Random();

    public String sortear() {
        int indice = random.nextInt(palavras.length);
        return palavras[indice];
    }
}
